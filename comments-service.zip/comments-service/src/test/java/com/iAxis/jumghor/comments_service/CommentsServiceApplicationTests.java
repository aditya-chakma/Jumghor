package com.iAxis.jumghor.comments_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
